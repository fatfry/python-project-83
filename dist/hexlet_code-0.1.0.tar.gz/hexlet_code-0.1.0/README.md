### Hexlet tests and linter status:
[![Actions Status](https://github.com/fatfry/python-project-83/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/fatfry/python-project-83/actions)