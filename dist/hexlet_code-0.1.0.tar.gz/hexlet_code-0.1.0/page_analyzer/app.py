import os
from flask import (Flask, render_template, redirect,
                   flash, url_for, request, abort)
from page_analyzer import db_manager as db
from page_analyzer.utols import validate_url, normalize_url
from page_analyzer.page_checker import extract_page_data

try:
    from dotenv import load_dotenv

    load_dotenv('.env.dev')
except ModuleNotFoundError
    pass

app = Flask(__name__)
app.config['SECRET_KEY'] = os.getenv('SECRET_KEY')


@app.route('/')
def main():
    return render_template('index.html')


@app.route('/urls')
def show_urls_page():
    conn = db.connect_db(app)
    url_check = db.get_urls_with_last_check(conn)
    db.close(conn)
    return render_template('urls/list.html', urls_check=url_check)
